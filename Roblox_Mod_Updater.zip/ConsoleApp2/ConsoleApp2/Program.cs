﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            WebClient wc = new WebClient();
            Console.WriteLine("console version: 3.0");
            Console.WriteLine("updating...");
            Console.WriteLine("if you get any errors, please run as admin.");
            wc.DownloadFile("https://github.com/Hmm465/RS_Modder/blob/master/RobloxStudioModManager.exe?raw=true", "RobloxStudioModManager.exe");
            wc.DownloadFile("https://raw.githubusercontent.com/Hmm465/RS_Modder/master/RobloxStudioModManager.exe.config", "RobloxStudioModManager.exe.config");
            wc.DownloadFile("https://raw.githubusercontent.com/Hmm465/RS_Modder/master/RobloxStudioModManager.exe.config", "RobloxStudioModManager.exe.config");
            wc.DownloadFile("https://github.com/Hmm465/RS_Modder/blob/master/RobloxStudioModManager.pdb?raw=true", "RobloxStudioModManager.pdb");
            wc.DownloadFile("https://raw.githubusercontent.com/Hmm465/RS_Modder/master/version.txt", "version.txt");
            Console.WriteLine("done... i think!");
        }
    }
}
